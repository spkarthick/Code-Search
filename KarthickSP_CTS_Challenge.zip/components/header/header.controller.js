(function(){
	
	var module = angular.module("header");
	
	module.controller("headerController", function() {
		var vm = this;
		vm.name = "header";
	});
	
})();