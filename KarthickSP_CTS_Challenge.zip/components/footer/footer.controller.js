(function(){
	
	var module = angular.module("footer");
	
	module.controller("footerController", function() {
		var vm = this;
		vm.name = "footer";
	});
	
})();